# k8s-admission-controller
Medium Article: [Build Your Own Admission Controllers in Kubernetes Using Go](https://bshayr29.medium.com/build-your-own-admission-controllers-in-kubernetes-using-go-bef8ba38d595).
